<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $userId = $_SESSION['user_id'];
    $comment = $_POST['comment'];

    try {
        $stmt = $pdo->prepare("INSERT INTO comments (user_id, comment) VALUES (?, ?)");
        $stmt->execute([$userId, $comment]);
    } catch (Exception $e) {

    }
}

$stmt = $pdo->query("SELECT comments.id, comments.comment, comments.created_at, users.username 
                      FROM comments 
                      JOIN users ON comments.user_id = users.id 
                      ORDER BY comments.created_at DESC");
$comments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обсуждения</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            margin: 0;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(181, 154, 154, 0.16);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        h2, h3, h4 {
            color: white;
            text-align: center;
        }

        form {
            margin-bottom: 20px;
        }

        form textarea {
            margin: 10px 0;
            padding: 10px;
            width: calc(100% - 22px);
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
            resize: vertical;
        }

        form button {
            background-color: #000033;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
            padding: 10px 20px;
        }

        form button:hover {
            background-color: #333366;
        }

        .comment {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .comment p {
            font-size: 16px;
            color: #333;
        }

        .comment small {
            color: #888;
            font-size: 14px;
        }

        .comment-actions a {
            color: #000033;
            text-decoration: none;
            margin-right: 10px;
        }

        .comment-actions a:hover {
            text-decoration: underline;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
        }

        .footer a {
            color: white;
            text-decoration: none;
            background-color: #000033;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .footer a:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">

    <h2>Обсуждения</h2>

    <form method="post">
        <textarea name="comment" required placeholder="Напишите ваш комментарий..."></textarea>
        <button type="submit">Добавить комментарий</button>
    </form>

    <div class="comments-section">
        <h3>Комментарии:</h3>

        <?php foreach ($comments as $comment): ?>
            <div class="comment">
                <strong><?php echo htmlspecialchars($comment['username']); ?></strong>:
                <p><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                <small>Опубликовано: <?php echo $comment['created_at']; ?></small>

                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <div class="comment-actions">
                        <a href="edit_comment.php?id=<?php echo $comment['id']; ?>">Редактировать</a>
                        <a href="delete_comment.php?id=<?php echo $comment['id']; ?>">Удалить</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="footer">
        <a href="solarsystem.php">Перейти к изучению солнечной системы!</a>
        <a href="dashboard.php">Вернуться в профиль</a>
    </div>
</div>

</body>
</html>

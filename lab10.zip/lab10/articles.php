<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Статьи и ресурсы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover; /* Фон растягивается на весь экран */
            background-position: center;
            background-attachment: fixed; /* Фон фиксируется при прокрутке */
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        h2 {
            color: #ffffff;
            font-size: 36px;
            margin-bottom: 20px;
        }

        .container {
            max-width: 600px;
            text-align: center;
            background-color: rgba(181, 154, 154, 0.16); 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            margin-bottom: 20px;
        }

        .resource-list {
            list-style-type: none;
            padding: 0;
            margin-bottom: 20px;
        }

        .resource-item {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: background-color 0.3s;
            background-color: #f0f0f0;
        }

        .resource-item:hover {
            background-color: #f0f0f0;
        }

        .resource-item a {
            text-decoration: none;
            color: rgb(35, 51, 89);
            font-weight: bold;
        }

        .resource-item a:hover {
            text-decoration: underline;
        }

        .footer {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            width: 100%;
        }

        .footer a {
            color: #ffffff;
            text-decoration: none;
            background-color: #000033;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            margin: 10px;
            opacity: 1; /* Убираем прозрачность */
        }

        .footer a:hover {
            background-color: #333366;
        }

        .back-button {
            color: white;
            background-color: #000033;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
            margin-top: 20px;
        }

        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Интересные ресурсы по астрономии</h2>
        <ul class="resource-list">
            <li class="resource-item">
                <a href="https://stellarium-web.org/" target="_blank">Карта звездного неба в реальном времени</a>
                <p>Наблюдайте за звездами, планетами и другими небесными объектами в реальном времени.</p>
            </li>
            <li class="resource-item">
                <a href="https://www.solarsystemscope.com/" target="_blank">Интерактивная карта Солнечной системы</a>
                <p>Исследуйте Солнечную систему с помощью интерактивной карты.</p>
            </li>
            <li class="resource-item">
                <a href="https://nattybumppo.github.io/rocket-launch-history/" target="_blank">История космонавтики</a>
                <p>Узнайте о всех запусках ракет с помощью интерактивной хронологии.</p>
            </li>
            <li class="resource-item">
                <a href="https://www.roscosmos.ru/" target="_blank">Роскосмос</a>
                <p>Официальный сайт Российской Федерации по космической деятельности.</p>
            </li>
            <li class="resource-item">
                <a href="https://www.ufo-hunters.com/" target="_blank">Поиск инопланетян</a>
                <p>Ресурс, посвященный поиску и исследованию неопознанных летающих объектов.</p>
            </li>
        </ul>
        
        <!-- Кнопки внутри контейнера -->
        <div class="footer">
            <a href="solarsystem.php" class="back-button">Назад</a> <!-- Кнопка назад -->
        </div>
    </div>
</body>
</html>


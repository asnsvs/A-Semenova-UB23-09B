<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Земля - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Земля</h1>
    
    <img src="planets/earth1.png" alt="Изображение Земли">
    
    <p>Земля — третья планета от Солнца и единственная известная планета, на которой существует жизнь. Она имеет уникальные условия, позволяющие поддерживать разнообразие жизни.</p>
    
    <p>Диаметр Земли составляет около 12,742 км. Уникальность Земли заключается в наличии воды в жидком состоянии, что является основным условием для жизни.</p>
    
    <img src="planets/earth2.png" alt="Изображение поверхности Земли">
    
    <p>Земля состоит из нескольких слоев: коры, мантии и ядра. Атмосфера Земли содержит кислород и азот, что делает её пригодной для дыхания.</p>
    
    <p>Земля вращается вокруг своей оси за примерно 24 часа, что создает день и ночь. Один год на Земле составляет около 365.25 дней.</p>
    
    <p>На поверхности Земли находятся океаны, горы, равнины и множество экосистем, что делает её разнообразной и уникальной среди других планет Солнечной системы.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
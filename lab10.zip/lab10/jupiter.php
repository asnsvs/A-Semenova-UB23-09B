<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Юпитер - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Юпитер</h1>
    
    <img src="planets/jupiter1.png" alt="Изображение Юпитера">
    
    <p>Юпитер — пятая планета от Солнца и крупнейшая планета в Солнечной системе. Его диаметр составляет около 139,822 км, что делает его более чем в 11 раз больше Земли.</p>
    
    <p>Юпитер — газовый гигант, состоящий в основном из водорода и гелия. У него нет твердой поверхности, и его атмосфера характеризуется мощными штормами и яркими облаками.</p>
    
    <img src="planets/jupiter2.png" alt="Изображение атмосферы Юпитера">
    
    <p>Одной из самых известных особенностей Юпитера является Большое Красное Пятно — гигантский шторм, который бушует уже более 350 лет. Этот шторм настолько велик, что в него может поместиться несколько планет размером с Землю.</p>
    
    <p>Юпитер имеет мощное магнитное поле и более 79 известных спутников, включая крупнейшие из них — Ио, Европа, Ганимед и Каллисто, которые известны как галилеевы спутники.</p>
    
    <p>На Ио находятся активные вулканы, Европа покрыта ледяной коркой и, возможно, имеет подземный океан, а Ганимед — единственный спутник в Солнечной системе с собственным магнитным полем.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
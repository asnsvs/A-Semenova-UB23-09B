<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Космос - Главная страница</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover; 
            background-position: center; 
            height: 100vh;


        }

        .container {
            max-width: 600px;
            margin: 100px auto;
            text-align: center;
            background-color: rgba(181, 154, 154, 0.16); 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        }

        h1 {
            font-size: 2.5em;
            color: white;
        }

        p {
            font-size: 1.2em;
            color: white;
        }

        .button-container {
            margin-top: 20px;
        }

        .button {
            display: inline-block;
            padding: 15px 30px;
            margin: 10px;
            background-color: #000033; 
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #333366; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Добро пожаловать в мир космоса!</h1>
        <p>Этот сайт предназначен для всех любителей космоса.</p>
        
        <div class="button-container">
            <a href="register.php" class="button">Зарегистрироваться</a>
            <a href="login.php" class="button">Войти</a>
        </div>
    </div>
</body>
</html>
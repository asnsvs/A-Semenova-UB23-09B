<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Статьи о планетах Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover; 
            background-position: center; 
            background-attachment: fixed; 
            height: 100vh; 
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            margin: 0;
        }

        h1 {
            text-align: center;
            color: #ffffff;
            margin-bottom: 20px;
            font-size: 36px;
        }

        .container {
            max-width: 600px;
            text-align: center;
            background-color: rgba(181, 154, 154, 0.16); 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            margin-bottom: 20px;
        }

        ul {
            list-style-type: none;
            padding: 0;
            margin: 20px 0;
        }

        li {
            margin: 15px 0;
        }

        a {
            display: block;
            text-decoration: none;
            color: white;
            background-color: #000033;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            transition: background-color 0.3s ease;
            font-size: 18px;
            font-weight: bold;
        }

        a:hover {
            background-color: #333366;
        }

        .footer {
            text-align: center;
            width: 100%;
            padding: 10px 0;
            margin-top: 20px;
        }

        .footer a {
            color: #ffffff;
            text-decoration: none;
            background-color: #000033;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            margin: 10px;
            display: inline-block;
        }

        .footer a:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Статьи о планетах Солнечной системы</h1>
        <ul>
            <li><a href="mercury.php">Меркурий - самая близкая к Солнцу планета, жаркая и кратерная</a></li>
            <li><a href="venus.php">Венера - жаркая и облачная, часто называется «сестрой Земли»</a></li>
            <li><a href="earth.php">Земля - единственная известная планета с жизнью</a></li>
            <li><a href="mars.php">Марс - красная планета с пустынными ландшафтами и полярными шапками</a></li>
            <li><a href="jupiter.php">Юпитер - самая большая планета Солнечной системы, газовый гигант с мощными штормами</a></li>
            <li><a href="saturn.php">Сатурн - известен своими великолепными кольцами, также газовый гигант</a></li>
            <li><a href="uranus.php">Уран - наклонная планета с уникальным цветом и холодной атмосферой</a></li>
            <li><a href="neptune.php">Нептун - темная и ветреная планета, самая удаленная от Солнца</a></li>
        </ul>
        <div class="footer">
            <a href="articles.php">Еще больше интересной информации!</a>
            <a href="discussion.php">Перейти к обсуждению!</a>
            <a href="dashboard.php">Вернуться в личный кабинет</a>
        </div>
    </div>
</body>
</html>

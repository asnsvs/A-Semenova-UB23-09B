<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Марс - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Марс</h1>
    
    <img src="planets/mars1.png" alt="Изображение Марса">
    
    <p>Марс — четвертая планета от Солнца и вторая по близости к Земле. Она известна своим красноватым цветом, который обусловлен высоким содержанием оксида железа на поверхности.</p>
    
    <p>Диаметр Марса составляет около 6,779 км, что делает его почти в два раза меньше Земли. Атмосфера Марса очень тонкая и состоит в основном из углекислого газа.</p>
    
    <img src="planets/mars2.png" alt="Изображение поверхности Марса">
    
    <p>На поверхности Марса находятся огромные вулканы, такие как Олимп — самый большой вулкан в Солнечной системе, а также глубокие каньоны, например, Вальес-Маринерис.</p>
    
    <p>Марс имеет сезонные изменения, которые влияют на его климат. Температуры на планете могут колебаться от -125°C зимой до +20°C летом.</p>
    
    <p>У Марса есть два небольших спутника — Фобос и Деймос, которые представляют собой захваченные астероиды. Исследования Марса продолжаются с помощью различных миссий, направленных на изучение его поверхности и возможности существования жизни.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
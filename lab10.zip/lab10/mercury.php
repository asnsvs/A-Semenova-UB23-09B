<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Меркурий - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Меркурий</h1>
    
    <img src="planets/mercury1.png" alt="Изображение Меркурия">
    
    <p>Меркурий — первая планета от Солнца и ближайшая к нему. Она известна своими экстремальными температурами и кратерами, которые образовались в результате столкновений с метеоритами.</p>
    
    <p>Диаметр Меркурия составляет около 4,880 км, что делает его самой маленькой планетой в Солнечной системе. Несмотря на близость к Солнцу, температура на поверхности Меркурия варьируется от -173°C ночью до 427°C днем из-за отсутствия атмосферы, способной удерживать тепло.</p>
    
    <img src="planets/mercury2.png" alt="Изображение поверхности Меркурия">
    
    <p>Меркурий имеет очень тонкую атмосферу, состоящую в основном из кислорода, натрия, водорода, гелия и калия. Это делает её неспособной защищать планету от солнечного излучения и метеоритов.</p>
    
    <p>Одной из интересных особенностей Меркурия является его высокая скорость вращения вокруг своей оси. Один день на Меркурии (период вращения) длится примерно 59 земных суток, но год (период обращения вокруг Солнца) составляет всего 88 земных суток.</p>
    
    <p>Меркурий также имеет множество кратеров, которые являются свидетельством его долгой истории столкновений. Эти кратеры варьируются по размеру и возрасту, некоторые из них имеют миллиарды лет.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: discussion.php"); // Перенаправление на страницу обсуждений, если не администратор
    exit();
}

if (isset($_GET['id'])) {
    $commentId = $_GET['id'];

    $stmt = $pdo->prepare("DELETE FROM comments WHERE id = ?");
    $stmt->execute([$commentId]);

    header("Location: discussion.php");
}
?>
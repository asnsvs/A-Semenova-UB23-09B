<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: discussion.php"); 
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['comment'])) {
    $commentId = $_POST['id'];
    $comment = $_POST['comment'];

    $stmt = $pdo->prepare("UPDATE comments SET comment = ? WHERE id = ?");
    $stmt->execute([$comment, $commentId]);

    header("Location: discussion.php");
    exit();
}

$commentId = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM comments WHERE id = ?");
$stmt->execute([$commentId]);
$comment = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать комментарий</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .container {
            max-width: 600px;
            padding: 20px;
            background-color: rgba(181, 154, 154, 0.16);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        h1 {
            color: white;
            margin-bottom: 20px;
        }

        form textarea {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            resize: vertical;
            box-sizing: border-box;
        }

        form button {
            background-color: #000033;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 5px;
        }

        form button:hover {
            background-color: #333366;
        }

        .footer {
            margin-top: 20px;
        }

        .footer a {
            color: white;
            text-decoration: none;
            background-color: #000033;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .footer a:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Редактировать комментарий</h1>

    <form method="post">
        <textarea name="comment" required><?php echo htmlspecialchars($comment['comment']); ?></textarea>
        <input type="hidden" name="id" value="<?php echo $comment['id']; ?>">
        <button type="submit">Сохранить изменения</button>
    </form>

    <div class="footer">
        <a href="discussion.php">Вернуться к обсуждению</a>
    </div>
</div>

</body>
</html>

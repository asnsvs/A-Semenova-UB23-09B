<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];

    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'user')");
        $stmt->execute([$username, $password, $email]);
        header("Location: login.php");
        exit();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { 
            $error_message = "Ошибка: это имя пользователя или email уже используются.";
        } else {
            $error_message = "Ошибка регистрации: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover; 
            background-position: center; 
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
            position: relative; 
        }

        h2 {
            color: white;
            text-align: center;
        }

        .container {
            max-width: 600px;
            margin: 100px auto;
            text-align: center;
            background-color: rgba(181, 154, 154, 0.16); 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
        }

        input[type="text"],
        input[type="password"],
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #000033;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
        }

        button:hover {
            background-color: #333366;
        }

        .error-message {
            color: red;
            background-color: rgba(255, 0, 0, 0.1);
            border: 1px solid red;
            padding: 10px;
            border-radius: 5px;
            margin-top: 15px;
        }

        .link-button {
            position: absolute; 
            bottom: 20px; 
            right: 20px; 
            padding: 10px;
            background-color: #000033; 
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
            text-decoration: none; 
        }

        .link-button:hover {
            background-color: #333366; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Регистрация</h2>
        
        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="text" name="username" placeholder="Имя пользователя" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <input type="email" name="email" placeholder="Email" required>
            <button type="submit">Зарегистрироваться</button>
            </form>
    </div>
    <a href="login.php" class="link-button">Уже есть аккаунт? Войти</a> 
</body>
</html>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Уран - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Уран</h1>
    
    <img src="planets/uranus1.png" alt="Изображение Урана">
    
    <p>Уран — седьмая планета от Солнца и третья по величине планета в Солнечной системе. Его диаметр составляет около 50,724 км, что делает его более чем четыре раза больше Земли.</p>
    
    <p>Уран известен своим характерным голубоватым цветом, который обусловлен наличием метана в его атмосфере. Эта планета является уникальной среди других газовых гигантов, так как она вращается на боку, наклонившись почти на 98 градусов относительно своей орбиты.</p>
    
    <img src="planets/uranus2.png" alt="Изображение атмосферы Урана">
    
    <p>Как и другие газовые гиганты, Уран состоит в основном из водорода и гелия, но также содержит значительное количество воды, аммиака и метана. Его атмосфера характеризуется сильными ветрами и облаками.</p>
    
    <p>Уран имеет сложную систему колец и более 27 известных спутников. Наиболее крупные из них — Титания, Оберон, Умбриэль, Ариэль и Миранда.</p>
    
    <p>Миранда известна своими необычными геологическими особенностями, включая огромные каньоны и обрывы. Спутники Урана имеют разнообразные поверхности и составы, что делает их интересными для изучения.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
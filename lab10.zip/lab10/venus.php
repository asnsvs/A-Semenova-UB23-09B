!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Венера - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Венера</h1>
    
    <img src="planets/venus1.png" alt="Изображение Венеры">
    
    <p>Венера — вторая планета от Солнца и ближайшая к Земле. Она известна своим ярким внешним видом и густой атмосферой, состоящей в основном из углекислого газа.</p>
    
    <p>Диаметр Венеры составляет около 12,104 км, что делает её почти такой же большой, как Земля. Однако температура на поверхности Венеры может достигать 465°C из-за сильного парникового эффекта.</p>
    
    <img src="planets/venus2.png" alt="Изображение поверхности Венеры">
    
    <p>Атмосфера Венеры очень плотная и содержит облака серной кислоты, что делает её непригодной для жизни. Давление на поверхности Венеры в 92 раза выше, чем на Земле.</p>
    
    <p>Интересно, что Венера вращается вокруг своей оси очень медленно — один день на Венере длится около 243 земных суток, а год — всего 225 земных суток.</p>
    
    <p>Поверхность Венеры усеяна вулканами и большими равнинами, и хотя она выглядит как "близнец" Земли, условия на ней совершенно не подходят для жизни.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
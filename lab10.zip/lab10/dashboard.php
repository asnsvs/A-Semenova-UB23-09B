<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST['edit_profile'])) {
        $edit_username = $_POST['edit_username'];
        $edit_email = $_POST['edit_email'];
        $edit_password = !empty($_POST['edit_password']) ? password_hash($_POST['edit_password'], PASSWORD_DEFAULT) : null;

        $check_stmt = $pdo->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
        $check_stmt->execute([$edit_username, $edit_email, $user_id]);
        $existing_user = $check_stmt->fetch();

        if ($existing_user) {
            $error_message = "Ошибка: имя пользователя или email уже заняты.";
        } else {
            if ($edit_password) {
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
                if ($stmt->execute([$edit_username, $edit_email, $edit_password, $user_id])) {
                    $success_message = "Данные профиля обновлены.";
                } else {
                    $error_message = "Ошибка при обновлении данных профиля.";
                }
            } else {
                $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
                if ($stmt->execute([$edit_username, $edit_email, $user_id])) {
                    $success_message = "Данные профиля обновлены.";
                } else {
                    $error_message = "Ошибка при обновлении данных профиля.";
                }
            }
        }
    }

    if ($_SESSION['role'] == 'admin') {
        if (isset($_POST['add_user'])) {
            $new_username = $_POST['new_username'];
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $new_email = $_POST['new_email'];

            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'user')");
            if ($stmt->execute([$new_username, $new_password, $new_email])) {
                $success_message = "Пользователь добавлен.";
            } else {
                $error_message = "Ошибка при добавлении пользователя.";
            }
        }


        if (isset($_POST['edit_user'])) {
            $edit_user_id = $_POST['edit_user_id'];
            $edit_user_password = !empty($_POST['edit_user_password']) ? password_hash($_POST['edit_user_password'], PASSWORD_DEFAULT) : null;
            $edit_user_email = $_POST['edit_user_email'];

            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $check_stmt->execute([$edit_user_email, $edit_user_id]);
            $existing_user = $check_stmt->fetch();

            if ($existing_user) {
                $error_message = "Ошибка: Email уже занят.";
            } else {
                if ($edit_user_password) {
                    $stmt = $pdo->prepare("UPDATE users SET password = ?, email = ? WHERE id = ?");
                    if ($stmt->execute([$edit_user_password, $edit_user_email, $edit_user_id])) {
                        $success_message = "Пользователь обновлен.";
                    } else {
                        $error_message = "Ошибка при обновлении пользователя.";
                    }
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
                    if ($stmt->execute([$edit_user_email, $edit_user_id])) {
                        $success_message = "Email пользователя обновлен.";
                    } else {
                        $error_message = "Ошибка при обновлении email пользователя.";
                    }
                }
            }
        }
        if (isset($_POST['promote_user'])) {
            $promote_user_id = $_POST['promote_user_id'];
        
            $stmt = $pdo->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
            if ($stmt->execute([$promote_user_id])) {
                echo "Пользователь успешно повышен до администратора.";
            } else {
                echo "Ошибка при повышении пользователя.";
            }
        }
        if (isset($_POST['delete_user'])) {
            $delete_user_id = $_POST['delete_user_id'];

            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            if ($stmt->execute([$delete_user_id])) {
                $success_message = "Пользователь удален.";
            } else {
                $error_message = "Ошибка при удалении пользователя.";
            }
        }
    }
}

$users_stmt = $pdo->query("SELECT * FROM users");
$all_users = $users_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('sky2.png');
            background-size: cover; 
            background-position: center; 
            background-attachment: fixed; /
            height: 100vh; 
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            margin: 0;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(181, 154, 154, 0.16);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        h2, h3, h4 {
            color: white;
            text-align: center;
        }

        .message {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
        }

        .error {
            color: red;
            background-color: rgba(255, 0, 0, 0.1);
            border: 1px solid red;
            padding: 10px;
        }

        .success {
            color: #155724;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
        }

        form {
            margin-bottom: 20px;
        }

        form input, form select, form button {
            margin: 10px 0;
            padding: 10px;
            width: calc(100% - 22px); 
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        form button {
            background-color: #000033;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            text-align: center;
        }

        form button:hover {
            background-color: #333366;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #333366;
            color: white;
        }

        table td {
            background-color: rgba(255, 255, 255, 0.8);
        }

        .footer {
            text-align: center;
            margin-top: 20px;
        }

        .footer a {
            color: white;
            text-decoration: none;
            background-color: #000033;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .footer a:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Добро пожаловать, <?php echo htmlspecialchars($user['username']); ?></h2>

        <?php if (!empty($error_message)): ?>
            <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <h3>Редактировать профиль</h3>
        <form method="POST">
            <input type="text" name="edit_username" placeholder="Имя пользователя" value="<?php echo htmlspecialchars($user['username']); ?>" required>

            <input type="email" name="edit_email" placeholder="Email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            <input type="password" name="edit_password" placeholder="Новый пароль (оставьте пустым, если не хотите менять)">
            <button type="submit" name="edit_profile">Сохранить изменения</button>
        </form>

        <?php if ($_SESSION['role'] == 'admin'): ?>
            <h3>Управление пользователями</h3>

            <h4>Добавить пользователя</h4>
            <form method="POST">
                <input type="text" name="new_username" placeholder="Имя пользователя" required>
                <input type="password" name="new_password" placeholder="Пароль" required>
                <input type="email" name="new_email" placeholder="Email" required>
                <button type="submit" name="add_user">Добавить</button>
            </form>

            <h4>Редактировать пользователя</h4>
            <form method="POST">
                <select name="edit_user_id" required>
                    <option value="">Выберите пользователя</option>
                    <?php foreach ($all_users as $u): ?>
                        <option value="<?php echo htmlspecialchars($u['id']); ?>"><?php echo htmlspecialchars($u['username']); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="password" name="edit_user_password" placeholder="Новый пароль (оставьте пустым, если не хотите менять)">
                <input type="email" name="edit_user_email" placeholder="Новый Email" required>
                <button type="submit" name="edit_user">Редактировать</button>
            </form>

            <h4>Повысить пользователя до администратора</h4>
            <form method="POST">
                <select name="promote_user_id" required>
                    <option value="">Выберите пользователя</option>
                    <?php foreach ($all_users as $u): ?>
                        <?php if ($u['role'] === 'user'): ?>
                            <option value="<?php echo htmlspecialchars($u['id']); ?>"><?php echo htmlspecialchars($u['username']); ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="promote_user">Повысить</button>
            </form>

            <h4>Удалить пользователя</h4>
            <form method="POST">
                <select name="delete_user_id" required>
                    <option value="">Выберите пользователя</option>
                    <?php foreach ($all_users as $u): ?>
                        <option value="<?php echo htmlspecialchars($u['id']); ?>"><?php echo htmlspecialchars($u['username']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="delete_user">Удалить</button>
            </form>

            <h4>Список пользователей</h4>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Имя пользователя</th>
                        <th>Email</th>
                        <th>Роль</th>
                        <th>Дата регистрации</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_users as $u): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($u['id']); ?></td>
                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td><?php echo htmlspecialchars($u['role']); ?></td>
                            <td><?php echo htmlspecialchars($u['created_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="footer">
            <a href="solarsystem.php">Перейти к изучению Солнечной системы!</a>
            <a href="discussion.php">Перейти к обсуждению!</a>
            <a href="logout.php">Выйти из профиля</a>
        </div>
    </div>
    <script>
        setTimeout(() => {
            const messages = document.querySelectorAll('.message');
            messages.forEach(message => {
                message.style.display = 'none';
            });
        }, 4000);
    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Нептун - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Нептун</h1>
    
    <img src="planets/neptune1.png" alt="Изображение Нептуна">
    
    <p>Нептун — восьмая и последняя планета от Солнца в Солнечной системе. Он является четвертой по величине планетой и третьей по массе. Диаметр Нептуна составляет около 49,244 км, что делает его чуть меньше Урана.</p>
    
    <p>Нептун известен своим ярким синеватым цветом, который также обусловлен наличием метана в его атмосфере. Эта планета обладает самой сильной атмосферной активностью среди всех планет Солнечной системы, включая сильные ветры и бурные штормы.</p>
    
    <img src="planets/neptune2.png" alt="Изображение атмосферы Нептуна">
    
    <p>Атмосфера Нептуна состоит в основном из водорода и гелия, с примесью метана и других углеводородов. На поверхности планеты наблюдаются яркие облака и шторма, которые могут достигать скорости до 2,100 км/ч.</p>
    
    <p>Нептун имеет систему колец и 14 известных спутников. Наиболее крупный из них — Тритон, который имеет уникальную ретроградную орбиту и активную геологию, включая гейзеры, выбрасывающие азот.</p>
    
    <p>Тритон является одним из самых интересных объектов для изучения благодаря своей необычной поверхности и возможному подледному океану. Другие спутники Нептуна также имеют разнообразные характеристики и составы.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
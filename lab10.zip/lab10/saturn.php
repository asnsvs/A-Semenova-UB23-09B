<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Сатурн - Планета Солнечной системы</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('stars.png');
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        img {
            width: 100%;
            height: auto;
            margin: 20px 0;
        }
        p {
            line-height: 1.6;
            color: #555;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #000033;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #333366;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Сатурн</h1>
    
    <img src="planets/saturn1.png" alt="Изображение Сатурна">
    
    <p>Сатурн — шестая планета от Солнца и вторая по величине планета в Солнечной системе после Юпитера. Его диаметр составляет около 116,460 км, что делает его более чем девять раз больше Земли.</p>
    
    <p>Сатурн известен своими великолепными кольцами, которые состоят в основном из льда и камней различного размера. Эти кольца делают планету одной из самых узнаваемых в Солнечной системе.</p>
    
    <img src="planets/saturn2.png" alt="Изображение колец Сатурна">
    
    <p>Как и Юпитер, Сатурн является газовым гигантом и состоит в основном из водорода и гелия. У него нет твердой поверхности, и его атмосфера содержит множество облаков и штормов.</p>
    
    <p>Сатурн имеет мощное магнитное поле и более 80 известных спутников, среди которых наиболее известны Титан, Рея, Дион и Энцелад.</p>
    
    <p>Титан — крупнейший спутник Сатурна и второй по величине спутник в Солнечной системе. Он имеет плотную атмосферу и озера жидкого метана на своей поверхности. Энцелад, в свою очередь, известен своими гейзерами, выбрасывающими воду и лед в космос.</p>

    <a href="javascript:history.back()" class="back-button">Назад</a>
</div>

</body>
</html>
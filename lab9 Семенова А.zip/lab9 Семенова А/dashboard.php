<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Редактирование данных пользователя
    if (isset($_POST['edit_profile'])) {
        $edit_username = $_POST['edit_username'];
        $edit_email = $_POST['edit_email'];
        $edit_password = !empty($_POST['edit_password']) ? password_hash($_POST['edit_password'], PASSWORD_DEFAULT) : null;

        // Обновляем только те поля, которые были изменены
        if ($edit_password) {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
            if ($stmt->execute([$edit_username, $edit_email, $edit_password, $user_id])) {
                echo "Данные профиля обновлены.";
            } else {
                echo "Ошибка при обновлении данных профиля.";
            }
        } else {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
            if ($stmt->execute([$edit_username, $edit_email, $user_id])) {
                echo "Данные профиля обновлены.";
            } else {
                echo "Ошибка при обновлении данных профиля.";
            }
        }
    }

    // Логика для администраторов
    if ($_SESSION['role'] == 'admin') {
        if (isset($_POST['add_user'])) {
            // Добавление нового пользователя
            $new_username = $_POST['new_username'];
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $new_email = $_POST['new_email'];

            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'user')");
            if ($stmt->execute([$new_username, $new_password, $new_email])) {
                echo "Пользователь добавлен.";
            } else {
                echo "Ошибка при добавлении пользователя.";
            }
        }

        if (isset($_POST['add_admin'])) {
            // Добавление нового администратора
            $new_admin_username = $_POST['new_admin_username'];
            $new_admin_password = password_hash($_POST['new_admin_password'], PASSWORD_DEFAULT);
            $new_admin_email = $_POST['new_admin_email'];

            $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'admin')");
            if ($stmt->execute([$new_admin_username, $new_admin_password, $new_admin_email])) {
                echo "Администратор добавлен.";
            } else {
                echo "Ошибка при добавлении администратора.";
            }
        }

        if (isset($_POST['edit_user'])) {
            // Редактирование пользователя
            $edit_user_id = $_POST['edit_user_id'];
            $edit_user_password = !empty($_POST['edit_user_password']) ? password_hash($_POST['edit_user_password'], PASSWORD_DEFAULT) : null;
            $edit_user_email = $_POST['edit_user_email'];

            // Обновляем только те поля, которые были изменены
            if ($edit_user_password) {
                $stmt = $pdo->prepare("UPDATE users SET password = ?, email = ? WHERE id = ?");
                if ($stmt->execute([$edit_user_password, $edit_user_email, $edit_user_id])) {
                    echo "Пользователь обновлен.";
                } else {
                    echo "Ошибка при обновлении пользователя.";
                }
            } else {
                $stmt = $pdo->prepare("UPDATE users SET email = ? WHERE id = ?");
                if ($stmt->execute([$edit_user_email, $edit_user_id])) {
                    echo "Email пользователя обновлен.";
                } else {
                    echo "Ошибка при обновлении email пользователя.";
                }
            }
        }

        if (isset($_POST['delete_user'])) {
            // Удаление пользователя
            $delete_user_id = $_POST['delete_user_id'];
            
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            if ($stmt->execute([$delete_user_id])) {
                echo "Пользователь удален.";
            } else {
                echo "Ошибка при удалении пользователя.";
            }
        }
    }
}

// Получаем всех пользователей для администраторов
$users_stmt = $pdo->query("SELECT * FROM users");
$all_users = $users_stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Панель управления</title>
</head>
<body>
    <h2>Добро пожаловать, <?php echo htmlspecialchars($user['username']); ?></h2>

    <!-- Форма редактирования профиля для обычных пользователей -->
    <h3>Редактировать профиль</h3>
    <form method="POST">
        <input type="text" name="edit_username" placeholder="Имя пользователя" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        <input type="email" name="edit_email" placeholder="Email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        <input type="password" name="edit_password" placeholder="Новый пароль (оставьте пустым, если не хотите менять)">
        <button type="submit" name="edit_profile">Сохранить изменения</button>
    </form>

    <?php if ($_SESSION['role'] == 'admin'): ?>
        <h3>Управление пользователями</h3>
        
        <h4>Добавить пользователя</h4>
        <form method="POST">
            <input type="text" name="new_username" placeholder="Имя пользователя" required>
            <input type="password" name="new_password" placeholder="Пароль" required>
            <input type="email" name="new_email" placeholder="Email" required>
            <button type="submit" name="add_user">Добавить</button>
        </form>

        <h4>Добавить администратора</h4>
        <form method="POST">
            <input type="text" name="new_admin_username" placeholder="Имя администратора" required>
            <input type="password" name="new_admin_password" placeholder="Пароль" required>
            <input type="email" name="new_admin_email" placeholder="Email" required>
            <button type="submit" name="add_admin">Добавить администратора</button>
        </form>

        <h4>Редактировать пользователя</h4>
        <form method="POST">
            <select name="edit_user_id" required>
                <option value="">Выберите пользователя</option>
                <?php foreach ($all_users as $u): ?>
                    <option value="<?php echo htmlspecialchars($u['id']); ?>"><?php echo htmlspecialchars($u['username']); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="password" name="edit_user_password" placeholder="Новый пароль (оставьте пустым, если не хотите менять)">
            <input type="email" name="edit_user_email" placeholder="Новый Email" required>
            <button type="submit" name="edit_user">Редактировать</button>
        </form>

        <h4>Удалить пользователя</h4>
        <form method="POST">
            <select name="delete_user_id" required>
                <option value="">Выберите пользователя</option>
                <?php foreach ($all_users as $u): ?>
                    <option value="<?php echo htmlspecialchars($u['id']); ?>"><?php echo htmlspecialchars($u['username']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" name="delete_user">Удалить</button>
        </form>

    <?php endif; ?>

    <h3>Ваши данные</h3>
    <p>Имя пользователя: <?php echo htmlspecialchars($user['username']); ?></p>
    <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
    <a href="logout.php">Выйти</a>
</body>
</html>
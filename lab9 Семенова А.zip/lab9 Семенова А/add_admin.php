<?php
include 'config.php';

// Проверяем, существует ли уже администратор
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
$adminCount = $stmt->fetchColumn();

if ($adminCount > 0) {
    echo "Администратор уже существует.";
    exit;
}

// Добавляем первого администратора
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_username = $_POST['admin_username'];
    $admin_password = password_hash($_POST['admin_password'], PASSWORD_DEFAULT);
    $admin_email = $_POST['admin_email'];

    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'admin')");
    if ($stmt->execute([$admin_username, $admin_password, $admin_email])) {
        echo "Первый администратор успешно добавлен.";
    } else {
        echo "Ошибка при добавлении администратора.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Добавить администратора</title>
</head>
<body>
    <h2>Добавить первого администратора</h2>
    <form method="POST">
        <input type="text" name="admin_username" placeholder="Имя пользователя" required>
        <input type="password" name="admin_password" placeholder="Пароль" required>
        <input type="email" name="admin_email" placeholder="Email" required>
        <button type="submit">Добавить администратора</button>
    </form>
</body>
</html>